//
// Created by Utilizador on 11-11-2019.
//

#include "Servicos.h"

#include <iostream>
#include <iomanip>
#include "Servicos.h"
using namespace std;


Servicos::Servicos(string servico, string prestador, float preco_mensal) {
    this->servico=servico;
    this->prestador=prestador;
    num_ocorrencias=0;
    this->preco_mensal=preco_mensal;
    disponivel=true;
}

string Servicos::getservico() const {
    return servico;
}

string Servicos::getprestador() const {
    return prestador;
}

int Servicos::getnumocorrencias() const {
    return num_ocorrencias;
}

float Servicos::getprecomensal() const {
    return preco_mensal;
}

bool Servicos::getdisponibilidade() const {
    return disponivel;
}

void Servicos::setservico(string servico) {
    this->servico=servico;
}

void Servicos::setprestador(string prestador) {
    this->prestador=prestador;
}

void Servicos::setdisponibilidade(bool disp) {
    disponivel=disp;
}

void Servicos::setprecomensal(string preco) {
    preco_mensal=stof(preco);
}

void Servicos::setprecomensal(float preco) {
    preco_mensal=preco;
}

void Servicos::setnumOcorrencias(int num_ocorr) {
    num_ocorrencias=num_ocorr;
}

void Servicos::startservico(int id,string cliente) {
    disponivel=false;
    Info_Servico tmp;
    tmp.servico=(servico+"-"+prestador);
    tmp.id =id;
    tmp.cliente=cliente;
    tmp.estado="A Decorrer...";
    time_t now=time(NULL);
    tmp.tempo_incial=*localtime(&now);
    tmp.tempo_incial.tm_mon++;
    tmp.tempo_incial.tm_year+=1900;
    historico_servicos.push_back(tmp);
}

void Servicos::cancelservico() {
    disponivel=true;
    historico_servicos.at(historico_servicos.size()-1).estado="Cancelado";
    time_t now=time(NULL);
    historico_servicos.at(historico_servicos.size()-1).tempo_final=*localtime(&now);
    historico_servicos.at(historico_servicos.size()-1).tempo_final.tm_mon++;
    historico_servicos.at(historico_servicos.size()-1).tempo_final.tm_year+=1900;
}

void Servicos::finishservico() {
    disponivel=true;
    num_ocorrencias++;
    historico_servicos.at(historico_servicos.size()-1).estado="Terminado";
    time_t now=time(NULL);
    historico_servicos.at(historico_servicos.size()-1).tempo_final=*localtime(&now);
    historico_servicos.at(historico_servicos.size()-1).tempo_final.tm_mon++;
    historico_servicos.at(historico_servicos.size()-1).tempo_final.tm_year+=1900;
}

void Servicos::printhistoricobylocal( int id) {
    for (int i = 0; i <historico_servicos.size() ; i++) {
        if (historico_servicos.at(i).id==id){
            if (historico_servicos.at(i).estado=="A Decorrer...")
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(27)<<"--:--:-- --/--/----"<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
            else
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(10)<<historico_servicos.at(i).tempo_final.tm_hour<<":"<<historico_servicos.at(i).tempo_final.tm_min<<":"<<historico_servicos.at(i).tempo_final.tm_sec<<" "<<historico_servicos.at(i).tempo_final.tm_mday<<"/"<<historico_servicos.at(i).tempo_final.tm_mon<<"/"<<historico_servicos.at(i).tempo_final.tm_year<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
        }
    }
}

void Servicos::printhistoricobyestado(string estado) {
    for (int i = 0; i <historico_servicos.size() ; i++) {
        if (historico_servicos.at(i).estado==estado){
            if (historico_servicos.at(i).estado=="A Decorrer...")
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(27)<<"--:--:-- --/--/----"<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
            else
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(10)<<historico_servicos.at(i).tempo_final.tm_hour<<":"<<historico_servicos.at(i).tempo_final.tm_min<<":"<<historico_servicos.at(i).tempo_final.tm_sec<<" "<<historico_servicos.at(i).tempo_final.tm_mday<<"/"<<historico_servicos.at(i).tempo_final.tm_mon<<"/"<<historico_servicos.at(i).tempo_final.tm_year<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
        }
    }
}

void Servicos::printhistoricobycliente(string cliente) {
    for (int i = 0; i <historico_servicos.size() ; i++) {
        if (historico_servicos.at(i).cliente==cliente){
            if (historico_servicos.at(i).estado=="A Decorrer...")
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(27)<<"--:--:-- --/--/----"<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
            else
                cout<<left<<setw(30)<<historico_servicos.at(i).servico<<
                    right<<setw(3)<<historico_servicos.at(i).id<<
                    right<<setw(20)<<historico_servicos.at(i).tempo_incial.tm_hour<<":"<<historico_servicos.at(i).tempo_incial.tm_min<<":"<<historico_servicos.at(i).tempo_incial.tm_sec<<" "<<historico_servicos.at(i).tempo_incial.tm_mday<<"/"<<historico_servicos.at(i).tempo_incial.tm_mon<<"/"<<historico_servicos.at(i).tempo_incial.tm_year<<
                    right<<setw(10)<<historico_servicos.at(i).tempo_final.tm_hour<<":"<<historico_servicos.at(i).tempo_final.tm_min<<":"<<historico_servicos.at(i).tempo_final.tm_sec<<" "<<historico_servicos.at(i).tempo_final.tm_mday<<"/"<<historico_servicos.at(i).tempo_final.tm_mon<<"/"<<historico_servicos.at(i).tempo_final.tm_year<<
                    right<<setw(20)<<historico_servicos.at(i).estado<<endl;
        }
    }
}

void Servicos::imprime() const {
    cout<<"Tipo de Servico......: "<<servico<<"\n"
        <<"Prestador............: "<<prestador<<"\n"
        <<"Preco Mensal.........: "<<preco_mensal<<"\n"
        <<"Numero de ocorrencias: "<<num_ocorrencias<<"\n"
        <<"Disponivel...........: ";
    if(disponivel)
        cout<<"Sim"<<"\n\n";
    else
        cout<<"Nao"<<"\n\n";
}

void Servicos::setRegisto(Info_Servico temp) {
    historico_servicos.push_back(temp);
}
