var searchData=
[
  ['areaexterior_221',['areaExterior',['../class_vivenda.html#a4a834dbe905f57b8692f778801977c47',1,'Vivenda']]],
  ['areahabitacional_222',['areaHabitacional',['../class_habitacao.html#ac0d53c560b187f8f6234ab2b68db51bc',1,'Habitacao']]]
];
